export const appMinusIcon = {
    data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><!--Font Awesome Pro 6.0.0-alpha2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License)--><defs><style>.fa-secondary{opacity:.4}</style></defs><path d="M392 296H56C33.906 296 16 278.094 16 256S33.906 216 56 216H392C414.094 216 432 233.906 432 256S414.094 296 392 296Z" class="fa-secondary"/></svg>`,
    name: 'minus'
};