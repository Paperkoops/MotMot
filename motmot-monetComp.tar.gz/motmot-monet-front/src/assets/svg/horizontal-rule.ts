export const appHorizontalRuleIcon = {
    data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--Font Awesome Pro 6.0.0-alpha2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License)--><defs><style>.fa-secondary{opacity:.4}</style></defs><path d="M640 255.874V255.874C640 273.543 625.543 288 607.874 288H31.874C14.343 288 0 273.657 0 256.126V256.126C0 238.457 14.457 224 32.126 224H608.126C625.73 224 640 238.27 640 255.874Z" class="fa-secondary"/></svg>`,
    name: 'horizontal-rule'
};