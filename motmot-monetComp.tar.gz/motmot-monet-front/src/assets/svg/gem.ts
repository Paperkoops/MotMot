export const appGemIcon = {
    data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--Font Awesome Pro 6.0.0-alpha2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License)--><defs><style>.fa-secondary{opacity:.4}</style></defs><path d="M256 192L400 64H112L256 192ZM222.25 224L112 64L0 224H222.25ZM512 224L400 64L289.75 224H512Z" class="fa-secondary"/><path d="M512 224L267.688 474.938C264.656 478.172 260.438 480 256 480S247.344 478.172 244.312 474.938L0 224H512Z" class="fa-primary"/></svg>`,
    name: 'gem'
};