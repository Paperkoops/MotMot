export const appUnionIcon = {
    data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><!--Font Awesome Pro 6.0.0-alpha2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License)--><defs><style>.fa-secondary{opacity:.4}</style></defs><path d="M192 480C86.125 480 0 393.875 0 288V72C0 49.906 17.906 32 40 32S80 49.906 80 72V288C80 349.75 130.25 400 192 400S304 349.75 304 288V72C304 49.906 321.906 32 344 32S384 49.906 384 72V288C384 393.875 297.875 480 192 480Z" class="fa-secondary"/></svg>`,
    name: 'union'
};