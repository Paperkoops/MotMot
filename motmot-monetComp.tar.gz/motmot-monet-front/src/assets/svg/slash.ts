export const appSlashIcon = {
    data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><!--Font Awesome Pro 6.0.0-alpha2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License)--><defs><style>.fa-secondary{opacity:.4}</style></defs><path d="M24.032 0C29.189 0 34.407 1.672 38.814 5.109L630.811 469.102C641.249 477.274 643.061 492.367 634.874 502.805C626.749 513.211 611.686 515.086 601.186 506.883L9.189 42.89C-1.249 34.718 -3.061 19.625 5.126 9.187C9.845 3.156 16.907 0 24.032 0Z" class="fa-secondary"/></svg>`,
    name: 'slash'
};