export const appFolderBlankIcon = {
    data: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><!--Font Awesome Pro 6.0.0-alpha2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License)--><defs><style>.fa-secondary{opacity:.4}</style></defs><path d="M512 144V432C512 458.5 490.5 480 464 480H48C21.5 480 0 458.5 0 432V80C0 53.5 21.5 32 48 32H208L272 96H464C490.5 96 512 117.5 512 144Z" class="fa-secondary"/></svg>`,
    name: 'folder-blank'
};