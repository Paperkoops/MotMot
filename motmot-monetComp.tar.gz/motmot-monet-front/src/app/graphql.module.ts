import { NgModule } from '@angular/core';
import { APOLLO_OPTIONS, Apollo } from 'apollo-angular';
import { ApolloClientOptions, ApolloLink, InMemoryCache } from '@apollo/client/core';
import { HttpLink } from 'apollo-angular/http';
import { setContext } from '@apollo/client/link/context';
import { CookieService } from 'ngx-cookie-service';
import { JwtHelperService } from '@auth0/angular-jwt';
import { environment } from 'src/environments/environment';
//const uri = 'http://localhost:3050/graphql'; // <-- add the URL of the GraphQL server here
//const uri = 'https://graphql-voter-app.herokuapp.com/'; // <-- add the URL of the GraphQL server here
export function createApollo(
  httpLink: HttpLink,
  cookieService: CookieService
): ApolloClientOptions<any> {
  const helper = new JwtHelperService();


  const basic = setContext((operation, context) => ({

    headers: {
      Accept: 'charset=utf-8',
      Operation: operation.operationName
    }
  }));

  const auth = setContext((operation , context ) => {

    const token = cookieService.get('token') || null;
    const isExpired = helper.isTokenExpired(token!);
    if (token === null || isExpired) {
      cookieService.delete('token')
      if( operation.operationName != 'login' && operation.operationName != "signup"){
         throw new Error("TokenExpired")
      }else{
        return {}
      }
    } else {
      return {
        headers: {
          Authorization: token,
        }
      };
    }

  });
  const link = ApolloLink.from([basic, auth, httpLink.create({ uri:environment.URIBackend + '/graphql' })]);
  const cache = new InMemoryCache();
  return {
    link,
    cache
  };
}

@NgModule({
  providers: [
    {
      provide: APOLLO_OPTIONS,
      useFactory: createApollo,
      deps: [HttpLink, CookieService],
    },

  ],
})
export class GraphQLModule { }
