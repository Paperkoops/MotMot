import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { JwtHelperService } from '@auth0/angular-jwt';


@Injectable({
  providedIn: 'root'
})
export class RequestHeadersService implements HttpInterceptor {

  constructor(
    private cookieService: CookieService
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const helper = new JwtHelperService();
    let token = this.cookieService.get('token') || null;
    const isExpired = helper.isTokenExpired(token!);
    if (isExpired) {
      token = '';
    }
    let request = req.clone({
      setHeaders: { Authorization: `${token}` },
    });
    return next.handle(request).pipe(
      finalize(() => {console.log("headers modificados")}));
  }
}
