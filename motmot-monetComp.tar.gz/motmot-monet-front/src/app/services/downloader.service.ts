import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, ObservableInput, throwError } from 'rxjs';

import { UploadImageInterface, UserStateLogged } from '@app/interfaces/data.interface';
import { CookieService } from 'ngx-cookie-service';
import { createSelector } from '@reduxjs/toolkit';
import { Store } from '@ngrx/store';
import * as loggedUserSlice from '../state/logged-user/logged-user-slice';
import { UserService } from './user.service';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class DownloaderService {
  constructor(private http: HttpClient, private cookieService:CookieService, private store:Store<{}>, private userService:UserService) {}
  logedUserInfo$ = this.store.select(
    createSelector(loggedUserSlice.selectFeature, (state) => state)
  );
  userInfo!: UserStateLogged;
  downloadFile(route: string, extension: string = '.png'): string {
    var stateObserver2 = this.logedUserInfo$.subscribe((data) => {
      this.userInfo = data;
    });
    if(parseInt(this.userInfo.credits) <=0){
      return "No credits";
    }
    const baseUrl = environment.URIBackend + '/download/';
    const token = '';
    const headers = new HttpHeaders().set('authorization', 'Bearer ' + token);
    //this.http.get(baseUrl + route,{headers, responseType: 'blob' as 'json'}).subscribe(
    this.http
      .get(baseUrl + route, { headers, responseType: 'blob' as 'json' })
      .subscribe((response: any) => {
        console.log(response.type);

        console.log(response);
        let dataType = response.type;
        let binaryData = [];
        binaryData.push(response);
        let downloadLink = document.createElement('a');
        downloadLink.href = window.URL.createObjectURL(
          new Blob(binaryData, { type: dataType })
        );

        downloadLink.setAttribute(
          'download',
          this.makeRandom(10).concat(extension)
        );
        document.body.appendChild(downloadLink);
        downloadLink.click();
      });

      this.userService.getDataUser(
        this.userInfo.id,
        false
      );
      return "Success";
  }

  uploadFile(img: any, title:string, desc:string) {
    const baseUrl = environment.URIBackend +'/image';
    const token = this.cookieService.get('token');
    const headers = new HttpHeaders().set('authorization', token);
    /*this.http.post(baseUrl, { headers}).subscribe((response: any) =>{

    })*/
    const hero = {
      filezzz: img,
    };
    console.log("ESTO ES LO QUE SE ESTA ENVIANDING", img)
    let testData:FormData = new FormData();
    testData.append('image', img, img.name);
    testData.append('title', title);
    testData.append('desc', desc);

    // return this.http
    //   .post<UploadImageInterface>(baseUrl, testData, { headers })
    //   .pipe(
    //     catchError(this.handleError)
    //   );
    // return this.http.post<UploadImageInterface>(baseUrl, testData, { headers }).subscribe({
    //   next: data => {
    //       console.log("se insertara la imagen con id", data.name);

    //   },
    //   error: error => {
    //       //this.errorMessage = error.message;
    //       console.error('There was an error!', error);
    //   }
    //})

    this.http.post<UploadImageInterface>(baseUrl, testData, { headers })
      .pipe(
        catchError(this.handleError)
      ).subscribe({
          next: data => {
              console.log("se insertara la imagen con id", data.name);

          },
          error: error => {
              //this.errorMessage = error.message;
              console.error('There was an error!', error);
          }});


  }
  private handleError(error: HttpErrorResponse) {
    if (error.status === 0) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, body was: `, error.error);
    }
    // Return an observable with a user-facing error message.
    return throwError(
      'Something bad happened; please try again later.');
  }
  /*handleError(err: string, hero: { image: any; }): (err: any, caught: Observable<Object>) => ObservableInput<any> {
    //throw new Error('Method not implemented.');
    if (err === "0") {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', err);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${err}, body was: `, err);
    }
    // Return an observable with a user-facing error message.
     throw new Error('Something bad happened; please try again later.');
  }*/
  /*handleError(err:any, caught:Observable<Object>):ObservableInput<any>{
    return
  }*/

  /*addHero(hero: Hero): Observable<Hero> {
    return this.http.post<Hero>(this.heroesUrl, hero, httpOptions)
      .pipe(
        catchError(this.handleError('addHero', hero))
      );
  }*/


  makeRandom(
    lengthOfCode: number,
    possible: string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890qwertyuiopasdfghjklzxcvbnm'
  ): string {
    let text = '';
    for (let i = 0; i < lengthOfCode; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    return text;
  }
}
