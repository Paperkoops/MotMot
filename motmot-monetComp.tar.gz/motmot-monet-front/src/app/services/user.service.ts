import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Apollo, gql } from 'apollo-angular';
import { Observable } from 'rxjs';
import { UserState, UserStateLogged } from '../state/interfaces/data.interface';
//import { setUser } from '../state/old/user/user.actions';
//import { AppState } from '../state/app.state';
import { take } from 'rxjs/operators';

import * as loggedUserSlice from 'src/app/state/logged-user/logged-user-slice';
import * as profileUserSlice from 'src/app/state/user-profile/user-profile-slice';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  user$: Observable<UserState> | undefined;
  constructor(
    private apollo: Apollo,
    private route: Router,
    private store: Store<{}>,
  ) {  }

  getDataUser(IdUser: string,toHome:boolean): void {
    try {
      const GET_USER = gql`
      query User($id:String!){
        user(id: $id){
          username
          email
          firstname
          lastname
          bio
          img
          credits
        }
      }
      `;
      this.apollo.watchQuery<any>({
        query: GET_USER,
        variables: {
          id: IdUser
        },
        fetchPolicy: 'network-only'
      }).valueChanges.pipe(take(1)).subscribe(({ data }) => {
        const userIns:UserStateLogged = {
          id: '',
          email: data.user.email,
          username: data.user.username,
          firstname: data.user.firstname,
          lastname: data.user.lastname,
          img: data.user.img,
          bio: data.user.bio,
          credits: data.user.credits,
        }
        //this.store.dispatch(setUser({user:userIns}));
        this.store.dispatch(loggedUserSlice.setUser(userIns));
        if(toHome){
          this.route.navigate(['/']);
        }
      }, (error) => {
        console.log('there was an error sending the query', error);
      });
    } catch (error) {
     console.log(error);
    }
  }

  getDataUserProfile(IdUser: string): void {
    try {
      const GET_USER = gql`
      query User($id:String!){
        user(id: $id){
          username
          email
          firstname
          lastname
          bio
          img
        }
      }
      `;
      this.apollo.watchQuery<any>({
        query: GET_USER,
        variables: {
          id: IdUser
        },
        fetchPolicy: 'network-only'
      }).valueChanges.pipe(take(1)).subscribe(({ data }) => {
        const userIns:UserState = {
          id: '',
          email: data.user.email,
          username: data.user.username,
          firstname: data.user.firstname,
          lastname: data.user.lastname,
          img: data.user.img,
          bio: data.user.bio,
        }
        //this.store.dispatch(setUser({user:userIns}));
        this.store.dispatch(profileUserSlice.setUser(userIns));
      }, (error) => {
        console.log('there was an error sending the query', error);
      });
    } catch (error) {
     console.log(error);
    }
  }
}
