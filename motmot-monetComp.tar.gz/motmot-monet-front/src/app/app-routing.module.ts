import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PageNotFoundComponent } from './routes/page-not-found/page-not-found.component';

const routes: Routes = [
  {
    path: 'pricing',
    loadChildren: () =>
      import('./routes/pricing-screen/pricing-screen.module').then(
        (m) => m.PricingScreenModule
      ),
  },
  {
    path: 'login',
    loadChildren: () =>
      import('./routes/login-screen/login-screen.module').then(
        (m) => m.LoginScreenModule
      ),
  },
  {
    path: 'search/:id',
    loadChildren: () =>
      import('./routes/search-screen/search-screen.module').then(
        (m) => m.SearchScreenModule
      ),
  },
  {
    path: '',
    loadChildren: () =>
      import('./routes/home-screen/home-screen.module').then(
        (m) => m.HomeScreenModule
      ),
  },
  { path: 'signup', loadChildren: () => import('./routes/signup-screen/signup-screen.module').then(m => m.SignupScreenModule) },
  { path: 'creator/:id', loadChildren: () => import('./routes/creator-screen/creator-screen.module').then(m => m.CreatorScreenModule) },
  //Wild Card Route for 404 request
  /* { path: '**', pathMatch: 'full',
  loadChildren: () =>
      import('./routes/page-not-found/page-not-found.component').then(
        (m) => m.PageNotFoundComponent
      ) }, */
      //Wild Card Route for 404 request
    { path: '**', pathMatch: 'full',
    component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
