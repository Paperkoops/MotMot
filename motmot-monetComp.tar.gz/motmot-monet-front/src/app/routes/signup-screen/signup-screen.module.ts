import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReactiveFormsModule } from '@angular/forms';

import { SignupScreenRoutingModule } from './signup-screen-routing.module';
import { SignupScreenComponent } from './signup-screen.component';
import { SvgIconsModule } from '@ngneat/svg-icon';


@NgModule({
  declarations: [
    SignupScreenComponent
  ],
  imports: [
    CommonModule,
    SignupScreenRoutingModule,
    ReactiveFormsModule,
    SvgIconsModule
  ]
})
export class SignupScreenModule { }
