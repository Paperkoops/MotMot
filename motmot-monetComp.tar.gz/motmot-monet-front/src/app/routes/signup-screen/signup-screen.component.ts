import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { JwtHelperService } from '@auth0/angular-jwt';
import { select, Store } from '@ngrx/store';
import { Apollo, gql } from 'apollo-angular';
import { CookieService } from 'ngx-cookie-service';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { UserService } from 'src/app/services/user.service';
//import { setIdUser } from 'src/app/state/old/user/user.actions';
//import { getUserData } from 'src/app/state/old/user/user.selectors';

import * as loggedUserSlice from 'src/app/state/logged-user/logged-user-slice';

@Component({
  selector: 'app-signup-screen',
  templateUrl: './signup-screen.component.html',
  styleUrls: ['./signup-screen.component.css']
})
export class SignupScreenComponent implements OnInit {
  private REGISTER_DATA = gql`
    mutation signup($username: String!, $password: String!, $email: String!, $firstname: String!, $lastname: String!, $bio: String!) {
      signup(username: $username, password: $password, email: $email, firstname: $firstname, lastname: $lastname, bio: $bio, img:"")
    }
  `;
  formRegister = new FormGroup({

    "email": new FormControl('', [
      Validators.required,
      Validators.email,
      Validators.minLength(5),
      Validators.maxLength(50)
    ]),
    "username": new FormControl('', [
      Validators.required,
      Validators.minLength(5),
      Validators.maxLength(50)
    ]),
    "password": new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(8)
    ]),
    "passwordConfirm": new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(8)
    ]),
    "firstname": new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(1)
    ]),
    "lastname": new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(1)
    ]),
    "bio": new FormControl('', [
      Validators.maxLength(500),
    ]),

  });

  stateObserver!:Subscription
  constructor(private apollo: Apollo,private toastr: ToastrService, private cookieService:CookieService, private store:Store, private userService:UserService) { }

  ngOnInit(): void {
  }

  signUp(): void{
    if (this.formRegister.valid) {
      if(this.formRegister.value.password == this.formRegister.value.passwordConfirm){
        this.apollo
        .mutate<any>({
          mutation: this.REGISTER_DATA,
          variables: {
            username: this.formRegister.value.username,
            password: this.formRegister.value.password,
            email: this.formRegister.value.email,
            firstname: this.formRegister.value.firstname,
            lastname: this.formRegister.value.lastname,
            bio: this.formRegister.value.bio
          },
          fetchPolicy: 'network-only'
        })
        .pipe(
          take(1),
          tap(
            ({ data }) => {
              this.cookieService.set('token', data.signup);
              console.log('se actualiza');
              console.log(this.cookieService.get('token'));
              this.toastr.success('Welcome', 'Signed up Successfully');
              const helper = new JwtHelperService();
              /*this.store.dispatch(
                setIdUser({ id: helper.decodeToken(data.signup).user._id })
              );*/

              //this.stateObserver = this.store.pipe(select(getUserData)).subscribe(data => {
              // console.log(data);
              //})
              this.store.dispatch(loggedUserSlice.setUserId(helper.decodeToken(data.login).user._id));

              this.userService.getDataUser(
                helper.decodeToken(data.signup).user._id,
                true
              );

              /*this.stateObserver = this.store
                .pipe(select(getUserData))
                .subscribe((data) => {
                  console.log(data);
                });*/
            },
            (error) => {
              console.log('pinche error UWU');
              console.log(error);
              this.toastr.error('Error', 'Check your credentials');
            }
          )
        )
        .subscribe();
      }
      else {
        this.toastr.warning('Passwords dont match', 'Check registration fields');
      }

    }
    else{
      this.toastr.error('Error', 'Check registration fields');
    }
  }

}
