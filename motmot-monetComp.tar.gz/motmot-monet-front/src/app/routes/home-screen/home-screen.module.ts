import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HomeScreenRoutingModule } from './home-screen-routing.module';
import { HomeScreenComponent } from './home-screen.component';
import { SearchBarModule } from '@app/components/search-bar/search-bar.module';
import { RecentsModule } from '@app/components/recents/recents.module';

@NgModule({
  declarations: [
    HomeScreenComponent
  ],
  imports: [
    CommonModule,
    HomeScreenRoutingModule,
    SearchBarModule,
    RecentsModule
  ]
})
export class HomeScreenModule { }
