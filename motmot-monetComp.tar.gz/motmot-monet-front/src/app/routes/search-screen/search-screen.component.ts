import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ImageListInterface } from '@app/interfaces/data.interface';
import { Apollo, gql } from 'apollo-angular';
import { ToastrService } from 'ngx-toastr';
import { take, tap } from 'rxjs/operators';
import { DownloaderService } from 'src/app/services/downloader.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-search-screen',
  templateUrl: './search-screen.component.html',
  styleUrls: ['./search-screen.component.css']
})
export class SearchScreenComponent implements OnInit {

  private GET_DATA = gql`
    query searchImages($search: String!){
      searchImages(search: $search){
        title,
        desc,
        link,
        owner{
          id,
          username
        }
      }
    }
  `;
  imageArray!:Array<ImageListInterface>;
  currentImage:ImageListInterface={
    title: "",
  desc: "",
  link: "",
  owner: {
    id: "",
    username: "",
  }
  };
  URIBackend:string = environment.URIBackend;
  constructor(private apollo:Apollo, private toastr:ToastrService, private router:ActivatedRoute, private downloaderService:DownloaderService) { }

  ngOnInit(): void {
    this.router.params.pipe(
      tap(({ id }) => {
        this.apollo
        .query<any>({
          query: this.GET_DATA,
          variables: {
            search: id,
          },
          fetchPolicy: 'network-only'
        })
        .pipe(
          take(1),
          tap(
            ({ data }) => {
              console.log("images de busqueda",data)
              this.imageArray = data.searchImages;
            },
            (error) => {
              console.log('pinche error UWU');
              console.log(error);
              this.toastr.error('Error', 'Cant get data from server');
            }
          )
        )
        .subscribe();
      })
    ).subscribe();


  }

  downloadSelectedImage(extension:string):void{
    const resp = this.downloaderService.downloadFile(this.currentImage.link, extension);
    if (resp == "Success") {
      this.toastr.success('Success', 'Image bought');
    } else {
      this.toastr.warning(resp, "Whoops")
    }
  }

}
