import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SearchScreenRoutingModule } from './search-screen-routing.module';
import { SearchScreenComponent } from './search-screen.component';
import { SearchBarModule } from 'src/app/components/search-bar/search-bar.module';
import { SvgIconsModule } from '@ngneat/svg-icon';


@NgModule({
  declarations: [
    SearchScreenComponent
  ],
  imports: [
    CommonModule,
    SearchScreenRoutingModule,
    SearchBarModule,
    SvgIconsModule
  ]
})
export class SearchScreenModule { }
