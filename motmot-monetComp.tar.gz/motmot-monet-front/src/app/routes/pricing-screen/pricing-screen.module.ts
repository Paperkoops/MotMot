import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PricingScreenRoutingModule } from './pricing-screen-routing.module';
import { PricingScreenComponent } from './pricing-screen.component';


@NgModule({
  declarations: [
    PricingScreenComponent
  ],
  imports: [
    CommonModule,
    PricingScreenRoutingModule
  ]
})
export class PricingScreenModule { }
