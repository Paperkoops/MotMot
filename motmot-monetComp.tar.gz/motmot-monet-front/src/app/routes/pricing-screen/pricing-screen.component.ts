import { Component, OnInit } from '@angular/core';
import { UserState, UserStateLogged } from '@app/interfaces/data.interface';
import { Store } from '@ngrx/store';
import { createSelector } from '@reduxjs/toolkit';
import { Apollo, gql } from 'apollo-angular';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { UserService } from 'src/app/services/user.service';
import * as loggedUserSlice from 'src/app/state/logged-user/logged-user-slice';

@Component({
  selector: 'app-pricing-screen',
  templateUrl: './pricing-screen.component.html',
  styleUrls: ['./pricing-screen.component.css']
})
export class PricingScreenComponent implements OnInit {
  stateObserver!:Subscription;
  addCreditsOption:string = '0';
  userInfo$ = this.store.select(
    createSelector(loggedUserSlice.selectFeature, (state) => state)
  );

  constructor(private apollo:Apollo, private store:Store, private userService:UserService, private toastr:ToastrService) { }

  userInfo!: UserStateLogged;
  private UPDATE_CREDITS = gql
  `mutation updateCredits($id: String!, $credits: String!){
    updateCredits(id: $id, credits: $credits){
      credits
      }
  } `;


  ngOnInit(): void {
    this.stateObserver = this.userInfo$.subscribe(data => {
      this.userInfo = data;
     });
  }

  addCredits(option:string): void {
    console.log(this.userInfo.id);

    try{
    this.apollo.mutate<any>({
          mutation: this.UPDATE_CREDITS,
          variables: {
            id: this.userInfo.id,
            credits: option
          },
          fetchPolicy: 'network-only'
        }).pipe(take(1),tap(({ data }) => {
          console.log("Creditos agregados");

          this.userService.getDataUser(
            this.userInfo.id,
            false
          );

          this.toastr.success("Tokens added", "Success")

        }, (error) => {
          console.log('there was an error sending the query', error);
          this.toastr.error("There was an error adding tokens", "Error");
        })).subscribe();
    } catch (error) {
      console.log(error);
    }

    }
}
