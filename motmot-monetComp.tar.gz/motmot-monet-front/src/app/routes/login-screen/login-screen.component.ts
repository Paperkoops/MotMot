import { Component, OnInit, OnDestroy } from '@angular/core';

import { Subscription } from 'rxjs';
import { Apollo, gql } from 'apollo-angular';
import { take, tap } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Store, select, createSelector } from '@ngrx/store';
//import { AppState } from 'src/app/state/app.state';
import { ToastrService, GlobalConfig } from 'ngx-toastr';

//import { setIdUser } from 'src/app/state/old/user/user.actions';
import { JwtHelperService } from '@auth0/angular-jwt';
//import { getUserData } from 'src/app/state/old/user/user.selectors';

import { NotiAlertComponent } from '@app/components/noti-alert/noti-alert.component';

import { UserService } from 'src/app/services/user.service';

import * as loggedUserSlice from 'src/app/state/logged-user/logged-user-slice';

import * as profileUserSlice from 'src/app/state/user-profile/user-profile-slice';

import { UserState } from '@app/interfaces/data.interface';
// We use the gql tag to parse our query string into a query document
/* const GET_DATA = gql`
  query user($userid:String!) {
    user(id: $userid) {
      firstname
    }
  }
`; */

@Component({
  selector: 'app-login-screen',
  templateUrl: './login-screen.component.html',
  styleUrls: ['./login-screen.component.css'],
})
export class LoginScreenComponent implements OnInit, OnDestroy {
  private GET_DATA = gql`
    mutation login($username: String!, $password: String!) {
      login(username: $username, password: $password)
    }
  `;
  /*   loading!: boolean;
  posts: any;

  private querySubscription!: Subscription; */
  private notiConf: GlobalConfig;
  private user: String = 'Ashiock';
  private pass: String = '123';
  formLogin = new FormGroup({
    username: new FormControl('', [
      Validators.required,
      Validators.minLength(5),
      Validators.maxLength(50),
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(8),
    ]),
  });

  private stateObserver!: Subscription;
  constructor(
    private apollo: Apollo,
    private cookieService: CookieService,
    private toastr: ToastrService,
    //private store: Store<AppState>,
    private userService: UserService,
    private readonly store: Store<{}>
  ) {
    this.notiConf = this.toastr.toastrConfig;
  }

  ngOnInit() {
    /*     this.querySubscription = this.apollo
      .watchQuery<any>({
        query: GET_POST,
      })
      .valueChanges.subscribe(({ data, loading }) => {
        this.loading = loading;
        this.posts = data.posts;
        console.log(this.posts);
      }); */
  }

  ngOnDestroy() {
    //this.querySubscription.unsubscribe();

  }

  counter$ = this.store.select(
    createSelector(loggedUserSlice.selectFeature, (state) => state)
  );


  login() {
    if (this.formLogin.valid) {
      this.user = this.formLogin.value.username;
      this.pass = this.formLogin.value.password;
      this.apollo
        .mutate<any>({
          mutation: this.GET_DATA,
          variables: {
            username: this.user,
            password: this.pass,
          },
          fetchPolicy: 'network-only'
        })
        .pipe(
          take(1),
          tap(
            ({ data }) => {
              this.cookieService.set('token', data.login);
              console.log('se actualiza');
              console.log(this.cookieService.get('token'));
              this.showSuccess();
              const helper = new JwtHelperService();
              /*this.store.dispatch(
                setIdUser({ id: helper.decodeToken(data.login).user._id })
              );*/

              //this.stateObserver = this.store.pipe(select(getUserData)).subscribe(data => {
              // console.log(data);
              //})
              this.store.dispatch(loggedUserSlice.setUserId(helper.decodeToken(data.login).user._id));
              this.userService.getDataUser(
                helper.decodeToken(data.login).user._id,
                true
              );

              /*this.stateObserver = this.store
                .pipe(select(getUserData))
                .subscribe((data) => {
                  console.log(data);
                });*/
            },
            (error) => {
              console.log('pinche error UWU');
              console.log(error);
              this.toastr.error('Error', 'Check your credentials');
            }
          )
        )
        .subscribe();

      /*.pipe(take(1)).subscribe(({data}) => {
      this.cookieService.set("token", data.login);
      console.log("se actualiza");
    }, (error)=> {console.log("pinche error UWU"); console.log(error)}); */
    } else {
      this.toastr.error('Error', 'Check your credentials');
    }
  }

  showSuccess() {
    /*const opt = this.notiConf;
    opt.toastComponent = NotiAlertComponent;
    opt.tapToDismiss = true;
    opt.timeOut = 5000;*/
    console.log('patataa');
    this.toastr.success('Welcome', 'Loged in successfully');
  }
}
