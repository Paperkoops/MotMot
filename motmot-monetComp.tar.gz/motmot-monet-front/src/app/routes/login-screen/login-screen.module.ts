import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';


import { LoginScreenRoutingModule } from './login-screen-routing.module';
import { LoginScreenComponent } from './login-screen.component';
import { SvgIconsModule } from '@ngneat/svg-icon';

import { ToastrModule } from 'ngx-toastr';
import counterReducer, { name as counterFeatureKey } from 'src/app/state/logged-user/logged-user-slice';
import profilrReducer, { name as profileFeatureKey } from 'src/app/state/user-profile/user-profile-slice';

import { StoreModule } from '@ngrx/store';


@NgModule({
  declarations: [
    LoginScreenComponent
  ],
  imports: [
    CommonModule,
    LoginScreenRoutingModule,
    SvgIconsModule,
    ReactiveFormsModule,
    ToastrModule,
    StoreModule.forFeature(counterFeatureKey, counterReducer),
    StoreModule.forFeature(profileFeatureKey, profilrReducer)
  ]
})
export class LoginScreenModule { }
