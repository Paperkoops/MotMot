import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ImageListInterface, UserState, UserStateLogged } from '@app/interfaces/data.interface';
import { Store, select, createSelector } from '@ngrx/store';
import { Apollo, gql } from 'apollo-angular';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { UserService } from 'src/app/services/user.service';
//import { AppState } from 'src/app/state/app.state';
//import { getUserData } from 'src/app/state/old/user/user.selectors';
import * as profileUserSlice from 'src/app/state/user-profile/user-profile-slice';
import * as loggedUserSlice from 'src/app/state/logged-user/logged-user-slice';
import { DownloaderService } from 'src/app/services/downloader.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-creator-screen',
  templateUrl: './creator-screen.component.html',
  styleUrls: ['./creator-screen.component.css'],
})
export class CreatorScreenComponent implements OnInit, OnDestroy {
  userProfileInfo$ = this.store.select(
    createSelector(profileUserSlice.selectFeature, (state) => state)
  );
  logedUserInfo$ = this.store.select(
    createSelector(loggedUserSlice.selectFeature, (state) => state)
  );

  private GET_DATA = gql`
    query searchImagesByCreator($search: String!) {
      searchImagesByCreator(search: $search) {
        title
        desc
        link
        owner {
          id
          username
        }
      }
    }
  `;

  private DELETE_IMAGE = gql`
    mutation deleteImage($id: String!) {
      deleteImage(id: $id)
    }
  `;
  imageArray!: Array<ImageListInterface>;
  currentImage: ImageListInterface = {
    title: '',
    desc: '',
    link: '',
    owner: {
      id: '',
      username: '',
    },
  };
  URIBackend: string = environment.URIBackend;
  isMyProfile: boolean = false;
  isEditing: boolean = false;

  constructor(
    private apollo: Apollo,
    private store: Store<{}>,
    private router: ActivatedRoute,
    private userService: UserService,
    private toastr: ToastrService,
    private downloaderService: DownloaderService
  ) {}
  ngOnDestroy(): void {
    //this.userProfileInfo$.subscribe();
  }

  private idCreator!: String;
  private stateObserver!: Subscription;
  private stateObserver2!: Subscription;
  userInfo!: UserState;
  loggedUser!:UserStateLogged;

  formEdit = new FormGroup({
    email: new FormControl('', [
      Validators.required,
      Validators.email,
      Validators.minLength(5),
      Validators.maxLength(50),
    ]),
    passwordOld: new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(8),
    ]),
    password: new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(8),
    ]),
    passwordConfirm: new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(8),
    ]),
    firstname: new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(1),
    ]),
    lastname: new FormControl('', [
      Validators.required,
      Validators.maxLength(30),
      Validators.minLength(1),
    ]),
    bio: new FormControl('', [Validators.maxLength(500)]),
  });

  ngOnInit(): void {
    this.router.params
      .pipe(
        tap(({ id }) => {
          this.idCreator = id;
          this.isMyProfile = false;
          this.store.dispatch(
            profileUserSlice.setUserId(this.idCreator.toString())
          );

          this.stateObserver2 = this.logedUserInfo$.subscribe((data) => {
            if (data.id == this.idCreator) {
              this.isMyProfile = true;
            }
            this.loggedUser = data;
          });

          this.userService.getDataUserProfile(this.idCreator.toString());

          this.apollo
            .query<any>({
              query: this.GET_DATA,
              variables: {
                search: this.idCreator.toString(),
              },
              fetchPolicy: 'network-only',
            })
            .pipe(
              take(1),
              tap(
                ({ data }) => {
                  console.log('images de busqueda', data);
                  this.imageArray = data.searchImagesByCreator;
                },
                (error) => {
                  console.log('pinche error UWU');
                  console.log(error);
                  this.toastr.error('Error', 'Cant get data from server');
                }
              )
            )
            .subscribe();
        })
      )
      .subscribe();

    /*this.stateObserver = this.store.pipe(select(getUserData)).subscribe(data => {
      this.userInfo = data;
    });*/
    this.stateObserver = this.userProfileInfo$.subscribe((data) => {
      this.userInfo = data;
      console.log(this.userInfo);
      this.formEdit.patchValue(data);
    });
  }

  downloadSelectedImage(extension: string): void {
    const resp = this.downloaderService.downloadFile(this.currentImage.link, extension);
    if (resp == "Success") {
      this.toastr.success('Success', 'Image bought');
    } else {
      this.toastr.warning(resp, "Whoops")
    }

  }

  deleteSelectedImage(): void {
    this.apollo
      .mutate<any>({
        mutation: this.DELETE_IMAGE,
        variables: {
          id: this.currentImage.link,
        },
        fetchPolicy: 'network-only',
      })
      .pipe(
        take(1),
        tap(
          ({ data }) => {
            this.toastr.success('Success', 'Image Deleted');
            let index = this.imageArray.indexOf(this.currentImage);
            if (index != -1) {
              window.location.reload();
            }
          },
          (error) => {
            console.log('pinche error UWU');
            console.log(error);
            this.toastr.error('Error', 'Couldn`t delete image');
          }
        )
      )
      .subscribe();
  }

  editProfile(): void {
    //console.log(this.formEdit.controls.firstname.erro);
    console.log(this.formEdit);

    if (this.formEdit.valid) {
      if (
        this.formEdit.controls.passwordConfirm.value !=
        this.formEdit.controls.password.value
      ) {
        this.toastr.error('Both passwords have to be the same', 'Error');
      } else {
        const UPDATE_USER = gql`
          mutation updateDataUser(
            $id:String!,
            $username:String!,
            $firstname:String!,
            $lastname:String!,
            $password: String!,
            $email: String!,
            $bio: String!,
            $passwordOLD:String!) {
            updateDataUser(
              id:$id,
              username:$username,
              firstname:$firstname,
              lastname:$lastname,
              password:$password,
              email:$email,
              bio:$bio,
              passwordOLD:$passwordOLD),
          }
        `;
       this.apollo.mutate<any>({
         mutation: UPDATE_USER,
         variables:{
          id:   this.idCreator,
          username: this.userInfo.username,
          firstname: this.formEdit.controls.firstname.value,
          lastname: this.formEdit.controls.lastname.value,
          passwordOLD:this.formEdit.controls.passwordOld.value,
          password: this.formEdit.controls.password.value,
          email: this.formEdit.controls.email.value,
          bio: this.formEdit.controls.bio.value,
         }
        }).pipe(take(1),tap(({data})=>{
          this.toastr.success(data.updateDataUser, 'success!', {
            closeButton: true,
            progressBar: true,
            timeOut: 1500,
          });
        },(error)=>{
          this.toastr.error(error, 'error!', {
            closeButton: true,
            progressBar: true,
            timeOut: 1500,
          });
        })).subscribe();
        this.formEdit.reset();
      }
    } else {
      this.toastr.error('Check the fields', 'Error');
    }
  }
}
