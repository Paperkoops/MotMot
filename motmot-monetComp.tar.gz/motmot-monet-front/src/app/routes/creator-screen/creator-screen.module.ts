import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreatorScreenRoutingModule } from './creator-screen-routing.module';
import { CreatorScreenComponent } from './creator-screen.component';
import { SvgIconsModule } from '@ngneat/svg-icon';
import profilrReducer, { name as profileFeatureKey } from 'src/app/state/user-profile/user-profile-slice';
import { StoreModule } from '@ngrx/store';

import { ReactiveFormsModule } from '@angular/forms';
import { NgBoringAvatarsModule } from 'ng-boring-avatars';



@NgModule({
  declarations: [
    CreatorScreenComponent
  ],
  imports: [
    CommonModule,
    CreatorScreenRoutingModule,
    SvgIconsModule,
    StoreModule.forFeature(profileFeatureKey, profilrReducer),
    ReactiveFormsModule,
    NgBoringAvatarsModule
  ]
})
export class CreatorScreenModule { }
