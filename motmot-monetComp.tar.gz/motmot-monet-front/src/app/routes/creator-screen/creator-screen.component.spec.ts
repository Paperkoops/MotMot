import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatorScreenComponent } from './creator-screen.component';

describe('CreatorScreenComponent', () => {
  let component: CreatorScreenComponent;
  let fixture: ComponentFixture<CreatorScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatorScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatorScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
