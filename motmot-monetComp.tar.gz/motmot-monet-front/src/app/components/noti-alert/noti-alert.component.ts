import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noti-alert',
  templateUrl: './noti-alert.component.html',
  styleUrls: ['./noti-alert.component.css']
})
export class NotiAlertComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
