import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotiAlertComponent } from './noti-alert.component';

describe('NotiAlertComponent', () => {
  let component: NotiAlertComponent;
  let fixture: ComponentFixture<NotiAlertComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotiAlertComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotiAlertComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
