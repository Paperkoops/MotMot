import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar.component';
import { RouterModule } from '@angular/router';
import { SvgIconsModule } from '@ngneat/svg-icon';

import counterReducer, { name as counterFeatureKey } from 'src/app/state/logged-user/logged-user-slice';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { StoreModule } from '@ngrx/store';

import { RequestHeadersService } from 'src/app/services/request-headers.service';

import { NgBoringAvatarsModule } from 'ng-boring-avatars';



@NgModule({
  declarations: [
    NavbarComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    SvgIconsModule,
    StoreModule.forFeature(counterFeatureKey, counterReducer),
    ReactiveFormsModule,
    HttpClientModule,
    NgBoringAvatarsModule
  ],
  exports: [
    NavbarComponent  ],
    providers: [
      { provide: HTTP_INTERCEPTORS, useClass: RequestHeadersService, multi: true }
    ]
})
export class NavbarModule { }
