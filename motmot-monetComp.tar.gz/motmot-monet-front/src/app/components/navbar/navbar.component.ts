import { Component, ElementRef, HostListener, Input, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserState } from '@app/interfaces/data.interface';
import { JwtHelperService } from '@auth0/angular-jwt';

import { Store, select, createSelector} from '@ngrx/store';
import { CookieService } from 'ngx-cookie-service';
import { Subscription } from 'rxjs';
//import { AppState } from 'src/app/state/app.state';
//import { resetUser, setIdUser } from 'src/app/state/old/user/user.actions';
import { ToastrService, GlobalConfig } from 'ngx-toastr';

import * as loggedUserSlice from 'src/app/state/logged-user/logged-user-slice';
import { FormGroup, FormControl, Validators } from '@angular/forms';
//import { getUserData } from 'src/app/state/old/user/user.selectors';
import { DownloaderService } from 'src/app/services/downloader.service';

//import { allowedImgTypesValidator } from 'src/app/directives/allowed-img-types.directive';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit, OnDestroy{
  @Input() progress: any;

  //file: File | null = null;
  file: File | null = null;
  //uploadLink!: string | ArrayBuffer | null;

  /*@HostListener('change', ['$event.target.files']) emitFiles( event: FileList ) {
    event.item
    const file = event && event.item(0);
    this.file = file;
  }*/
  private stateObserver!: Subscription;

  counter$ = this.store.select(
    createSelector(loggedUserSlice.selectFeature, (state) => state)
  );
  userInfo!: UserState;

  formUpload = new FormGroup({
    title: new FormControl('', [
      Validators.required,
      Validators.minLength(3),
      Validators.maxLength(30),
    ]),
    description: new FormControl('', [
      Validators.required,
      Validators.maxLength(80),
      Validators.minLength(5),
    ]),
    image: new FormControl('', [
      Validators.required,
      this.allowedImgTypesValidator('png')
    ]),
  });


  constructor(private downloaderService:DownloaderService, private cookieService:CookieService, private router:Router, private toastr:ToastrService, private readonly store: Store<{}>, private host: ElementRef<HTMLInputElement>) { }

  ngOnInit(): void {
    /*this.stateObserver = this.store.pipe(select(getUserData)).subscribe(data => {
      this.userInfo = data;
     });*/
     //this.userInfo = this.counter$;
     this.stateObserver = this.counter$.subscribe(data => {
      this.userInfo = data;
      console.log(this.userInfo)
     });


  }
  ngOnDestroy(): void {
    this.stateObserver.unsubscribe();
  }

  logout(): void{
    this.clearUpload();
    const helper = new JwtHelperService();
    this.cookieService.delete("token");
    this.router.navigate(['/login']);
    this.store.dispatch((loggedUserSlice.reset()));
    this.toastr.success('Goodbye!', 'Loged out successfully');
  }

  upload():void {
    if(this.formUpload.valid){
      console.log("Si es valido el upload");
      //console.log(this.downloaderService.uploadFile(this.formUpload.value.image))
      this.downloaderService.uploadFile(this.file, this.formUpload.value.title, this.formUpload.value.description)
      //.subscribe(hero => console.log(this.formUpload.value.image));
      this.toastr.success("Image uploaded successfully", "Success");
      this.clearUpload();
    }
    else{
      console.log("NOOO es valido el upload");
      this.toastr.error("Couldn't upload image, please check the upload fields", "Error");
    }
  }

  allowedImgTypesValidator( type: string ) {
    return function (control: FormControl) {
      const file = control.value;
      if ( file ) {
        console.log(file)
        const extension = file.split('.')[1].toLowerCase();
        console.log(type.toLowerCase(), extension.toLowerCase())
        if ( type.toLowerCase() !== extension.toLowerCase() ) {
          console.log("NOO es valido el tipo de archivo");
          return {
            requiredFileType: true
          };
        }
        console.log("Si es valido el tipo de archivo");
        return null;
      }

      return null;
    };
  }

  updateFileInput(event: Event) {
    const element = event.currentTarget as HTMLInputElement;
    let fileList: FileList | null = element.files;
    if (fileList) {
      /*console.log("FileUpload -> files", fileList);
      var fr = new FileReader();
      fr.readAsDataURL(fileList[0]);
      fr.onload = (e, patata=this.uploadLink) => {
        var rawLog = fr.result;
        console.log(rawLog);
        console.log(patata)
        patata = rawLog;
        console.log(patata)
    };*/

      //console.log(fr.result);
    }
    this.file = fileList?fileList[0]:null;

}

  clearUpload():void{
    this.formUpload.reset();
  }

}
/*function requiredFileType(arg0: string): import("@angular/forms").ValidatorFn {
  throw new Error('Function not implemented.');
}*/
