import { Component, OnInit } from '@angular/core';
import { Apollo, gql } from 'apollo-angular';
import { ToastrService } from 'ngx-toastr';
import { take, tap } from 'rxjs/operators';
import { ImageListInterface } from '@app/interfaces/data.interface';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-recents',
  templateUrl: './recents.component.html',
  styleUrls: ['./recents.component.css']
})
export class RecentsComponent implements OnInit {

  private GET_DATA = gql`
    query{
      imagesRecents{
        title,
        desc,
        link,
        owner{
          id,
          username
        }
      }
    }
  `;
  ImageArray!:Array<ImageListInterface>;
  URIBackend:string = environment.URIBackend;

  constructor(private apollo:Apollo, private toastr:ToastrService) { }

  ngOnInit(): void {

    this.apollo
        .query<any>({
          query: this.GET_DATA,
          fetchPolicy: 'network-only'
        })
        .pipe(
          take(1),
          tap(
            ({ data }) => {
              console.log("images",data)
              this.ImageArray = data.imagesRecents;
            },
            (error) => {
              console.log('pinche error UWU');
              console.log(error);
              this.toastr.error('Error', 'Cant get data from server');
            }
          )
        )
        .subscribe();
  }

}
