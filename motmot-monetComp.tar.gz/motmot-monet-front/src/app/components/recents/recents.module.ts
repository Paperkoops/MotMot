import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecentsComponent } from './recents.component';



@NgModule({
  declarations: [
    RecentsComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    RecentsComponent
  ]
})
export class RecentsModule { }
