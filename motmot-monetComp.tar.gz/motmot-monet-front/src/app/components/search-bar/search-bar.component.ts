import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormsModule } from '@angular/forms';

@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.css']
})
export class SearchBarComponent implements OnInit {

  curatedQuery:string = "";

  constructor() { }

  formSearch = new FormGroup({
    searchQuery: new FormControl('', [
      Validators.required,
      Validators.minLength(1),
      Validators.maxLength(50),
    ]),
  });

  ngOnInit(): void {

  }

  curateQuery(event: Event) {
    if(this.formSearch.valid){
      this.curatedQuery= this.formSearch.value.searchQuery;
      console.log("valida la query")
    }
  }

}
