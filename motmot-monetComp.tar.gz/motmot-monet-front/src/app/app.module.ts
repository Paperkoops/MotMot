import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SvgIconsModule } from '@ngneat/svg-icon';
import { NavbarModule } from '@app/components/navbar/navbar.module';
import { FooterModule } from '@app/components/footer/footer.module';
import { ReactiveFormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

import { appMotmotIcon } from '@app/svg/motmot';
import { appArrowRightToBracketIcon } from '@app/svg/arrow-right-to-bracket'
import { appCameraRetroIcon } from '@app/svg/camera-retro';
import { appUserPlusIcon } from '@app/svg/user-plus';
import { appMoneyBillWaveIcon } from '@app/svg/money-bill-wave';
import { appIdCardIcon } from '@app/svg/id-card';
import { appDownloadIcon } from '@app/svg/download';
import { appHexagonXmarkIcon } from '@app/svg/hexagon-xmark';
import { appCloudArrowUpIcon } from '@app/svg/cloud-arrow-up';
import { appImageIcon } from '@app/svg/image';
import { appArrowRightFromBracketIcon } from '@app/svg/arrow-right-from-bracket';
import { appTrashIcon } from '@app/svg/trash';

import { GraphQLModule } from './graphql.module';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { NotiAlertComponent } from './components/noti-alert/noti-alert.component';

//import { appReducer } from './state/app.state';

import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from '../environments/environment';
import { AllowedImgTypesDirective } from './directives/allowed-img-types.directive';
import { NgBoringAvatarsModule } from 'ng-boring-avatars';
import { PageNotFoundComponent } from './routes/page-not-found/page-not-found.component';


@NgModule({
  declarations: [
    AppComponent,
    NotiAlertComponent,
    AllowedImgTypesDirective,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NavbarModule,
    FooterModule,
    ReactiveFormsModule,
    SvgIconsModule.forRoot({
      icons: [appMotmotIcon, appTrashIcon, appArrowRightFromBracketIcon, appImageIcon, appCloudArrowUpIcon, appArrowRightToBracketIcon, appCameraRetroIcon, appUserPlusIcon, appMoneyBillWaveIcon, appIdCardIcon, appDownloadIcon, appHexagonXmarkIcon],
    }),

    CommonModule,
    BrowserAnimationsModule, // required animations module
    ToastrModule.forRoot(), // ToastrModule added

    GraphQLModule,
    HttpClientModule,
    //StoreModule.forRoot({}, {})
    //StoreModule.forRoot(appReducer),
    StoreModule.forRoot({}),
    StoreDevtoolsModule.instrument({ maxAge: 25, logOnly: environment.production }),
    NgBoringAvatarsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
