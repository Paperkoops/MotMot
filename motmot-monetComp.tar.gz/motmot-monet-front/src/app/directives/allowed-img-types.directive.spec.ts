import { AllowedImgTypesDirective } from './allowed-img-types.directive';

describe('AllowedImgTypesDirective', () => {
  it('should create an instance', () => {
    const directive = new AllowedImgTypesDirective();
    expect(directive).toBeTruthy();
  });
});
