import { Directive, Input } from '@angular/core';
import { AbstractControl, ValidationErrors, Validator, ValidatorFn } from '@angular/forms';

@Directive({
  selector: '[appAllowedImgTypes]'
})
export class AllowedImgTypesDirective implements Validator {

  constructor() { }
  @Input('appAllowedImgTypes') allowedImgTypes = '';

  validate(control: AbstractControl): ValidationErrors | null {
    return this.allowedImgTypes ? allowedImgTypesValidator(this.allowedImgTypes)(control)
                              : null;
  }

}

export function allowedImgTypesValidator(imgType: string): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const forbidden = (imgType!="ico")?true:false;
    return forbidden ? {forbiddenName: {value: control.value}} : null;
  };
}
