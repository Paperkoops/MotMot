import { Component, OnInit } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import { NavigationEnd, Router, Event } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Store, select, createSelector } from '@ngrx/store';
//import { AppState } from './state/app.state';
//import { setToken, setIdUser } from './state/old/user/user.actions';
//import { getUserData } from './state/old/user/user.selectors';
import { UserService } from './services/user.service';
import { take } from 'rxjs/operators';

import * as loggedUserSlice from 'src/app/state/logged-user/logged-user-slice';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit{
  title = 'motmot-monet-front';

  userInfo$ = this.store.select(
    createSelector(loggedUserSlice.selectFeature, (state) => state)
  );
  private stateObserver!: Subscription;
  constructor(
    private cookieService: CookieService,
    private router: Router,
    private store: Store<{}>,
    private userService: UserService
  ) {

  }
  ngOnInit(): void {
    const helper = new JwtHelperService();


    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd) {
        if (!this.cookieService.check('token')) {
          if (
            event.url.toString() != '/login' &&
            event.url.toString() != '/signup'
          ) {
            this.router.navigate(['/login']);
          }
        } else {
          const token = this.cookieService.get('token') || '';
          const isExpired = helper.isTokenExpired(token);
          if (isExpired) {
            this.cookieService.delete('token');
            this.router.navigate(['/login']);
          } else if (
            event.url.toString() == '/login' ||
            event.url.toString() == '/signup'
          ) {
            this.router.navigate(['/']);
          }

          this.stateObserver = this.userInfo$.pipe(take(1)).subscribe(data => {
            if (data.username === '') {
              this.store.dispatch(
                loggedUserSlice.setUserId(helper.decodeToken(this.cookieService.get('token')).user._id)
              );
              this.userService.getDataUser(
                helper.decodeToken(this.cookieService.get('token')).user._id,
                false
              );
            }
           });
          /*this.store.pipe(take(1), select(getUserData)).subscribe((data) => {
            if (data.username === '') {
              this.store.dispatch(
                setToken({ tokenValue: this.cookieService.get('token') })
              );
              this.store.dispatch(
                setIdUser({
                  id: helper.decodeToken(this.cookieService.get('token')).user
                    ._id,
                })
              );
              this.userService.getDataUser(
                helper.decodeToken(this.cookieService.get('token')).user._id,
                false
              );
            }
          }); */


        }
      }
    });


    /////////////////


  }


}
