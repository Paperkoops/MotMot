export interface UserState {
  id: string;
  email: string;
  username: string;
  firstname: string;
  lastname: string;
  img: string;
  bio: string;
}

export interface UserStateLogged {
  id: string;
  email: string;
  username: string;
  firstname: string;
  lastname: string;
  img: string;
  bio: string;
  credits:string;
}
export interface ImageInterface {}

export interface UploadImageInterface {
  success: object;
  name: string;
}

export interface ImageListInterface {
  title: string;
  desc: string;
  link: string;
  owner: {
    id: string;
    username: string;
  };
}

