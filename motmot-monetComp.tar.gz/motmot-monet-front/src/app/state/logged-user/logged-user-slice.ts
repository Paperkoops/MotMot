import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { createFeatureSelector } from '@ngrx/store';
import { UserStateLogged } from '@app/interfaces/data.interface';

const loggedUserSlice = createSlice({
  name: 'logged-user',
  initialState: {
    id: '',
    email: '',
    username: '',
    firstname: '',
    lastname: '',
    img: '',
    bio: '',
    credits: '',
  },
  reducers: {
    setUser: (state, action: PayloadAction<UserStateLogged>) => {
      //state.id = "6160fdeb7f7b8351cf074630";
      state.email = action.payload.email;
      state.username = action.payload.username;
      state.firstname = action.payload.firstname;
      state.lastname = action.payload.lastname;
      state.img = action.payload.img;
      state.bio = action.payload.bio;
      state.credits = action.payload.credits;
    },
    setUserId: (state, action: PayloadAction<string>) => {
      state.id = action.payload;
    },
    reset: (state) => {
      state.id = "";
      state.email = "";
      state.username = "";
      state.firstname = "";
      state.lastname = "";
      state.img = "";
      state.bio = "";
      state.credits = "";
    },
  },
});

const {
  reducer,
  actions: { setUser, setUserId, reset },
  name,
} = loggedUserSlice;

export default loggedUserSlice.reducer;
export { setUser, setUserId, reset, name };

export const selectFeature =
  createFeatureSelector<ReturnType<typeof reducer>>(name);
