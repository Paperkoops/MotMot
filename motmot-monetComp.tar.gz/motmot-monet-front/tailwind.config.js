module.exports = {
  purge: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [
    require('daisyui'),
  ],
  daisyui: {
    themes: [
      {
        'customMotmot': {                          /* your theme name */
           'primary' : '#1D4ED8',           /* Primary color */
           'primary-focus' : '#1E40AF',     /* Primary color - focused */
           'primary-content' : '#ffffff',   /* Foreground content color to use on primary color */

           'secondary' : '#D9A61C',         /* Secondary color */
           'secondary-focus' : '#F0AD05',   /* Secondary color - focused */
           'secondary-content' : '#000000', /* Foreground content color to use on secondary color */

           'accent' : '#10b981',            /* Accent color */
           'accent-focus' : '#0D9668',      /* Accent color - focused */
           'accent-content' : '#ffffff',    /* Foreground content color to use on accent color */

           'neutral' : '#1F2937',           /* Neutral color */
           'neutral-focus' : '#161D27',     /* Neutral color - focused */
           'neutral-content' : '#ffffff',   /* Foreground content color to use on neutral color */

           'base-100' : '#ffffff',          /* Base color of page, used for blank backgrounds */
           'base-200' : '#f9fafb',          /* Base color, a little darker */
           'base-300' : '#d1d5db',          /* Base color, even more darker */
           'base-content' : '#1f2937',      /* Foreground content color to use on base color */

           'info' : '#1D4ED8',              /* Info */
           'success' : '#0D9668',           /* Success */
           'warning' : '#F0AD05',           /* Warning */
           'error' : '#AD343E',             /* Error */
        },
      },
    ],
  },
}
